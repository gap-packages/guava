#ifndef ORBDES
#define ORBDES

extern int main( int argc, char *argv[])
;

#endif
