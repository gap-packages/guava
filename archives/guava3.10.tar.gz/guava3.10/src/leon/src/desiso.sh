#!/bin/sh

desauto -iso $*    
