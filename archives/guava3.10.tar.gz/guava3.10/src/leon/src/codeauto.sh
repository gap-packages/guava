#!/bin/sh

desauto -code $*
