#!/bin/sh

orblist -ptstab $* 
