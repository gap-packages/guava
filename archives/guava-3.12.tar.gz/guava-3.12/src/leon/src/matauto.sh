#!/bin/sh

desauto -matrix $*
