#!/bin/sh

desauto -iso -code $*
