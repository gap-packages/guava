/* some defines needed on SunOS 4.1.3 */

extern int printf();
extern int fprintf();
extern int close();
extern int fclose();
extern int fscanf();
