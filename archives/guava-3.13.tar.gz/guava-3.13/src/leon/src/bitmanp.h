#ifndef BITMANP
#define BITMANP

#endif
