#ifndef SETSTAB
#define SETSTAB

extern int main( int argc, char *argv[])
;

#endif
