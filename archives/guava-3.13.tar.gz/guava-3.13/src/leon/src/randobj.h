#ifndef RANDOBJ
#define RANDOBJ

extern int main(
   int argc,
   char *argv[])
;

extern void checkCompileOptions(
   char *localFileName,
   CompileOptions *mainOpts,
   CompileOptions *localOpts)
;

#endif
