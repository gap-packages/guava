#ifndef PRIMES
#define PRIMES

extern BOOLEAN isPrime(
   const Unsigned n)
;

#endif
