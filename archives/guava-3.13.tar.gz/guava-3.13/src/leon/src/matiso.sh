#!/bin/sh

desauto -iso -matrix $*
