#!/bin/sh

setstab -image $*
