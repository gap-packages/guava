#ifndef RANDPTS
#define RANDPTS

extern int main(
   int argc,
   char *argv[])
;

#endif
