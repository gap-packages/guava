#ifndef DESAUTO
#define DESAUTO

extern int main( int argc, char *argv[])
;

#endif
