#!/bin/sh

setstab -partn $*
