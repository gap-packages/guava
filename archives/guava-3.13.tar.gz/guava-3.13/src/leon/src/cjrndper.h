#ifndef CJRNDPER
#define CJRNDPER

extern int main(
   int argc,
   char *argv[])
;

#endif
