#ifndef FIELD
#define FIELD

extern Field *buildField(
   Unsigned size)
;

#endif
