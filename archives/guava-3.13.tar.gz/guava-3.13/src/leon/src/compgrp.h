#ifndef COMPGRP
#define COMPGRP

extern int main( int argc, char *argv[])
;

#endif
