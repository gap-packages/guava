#ifndef FNDELT
#define FNDELT

extern int main( int argc, char *argv[])
;

#endif
