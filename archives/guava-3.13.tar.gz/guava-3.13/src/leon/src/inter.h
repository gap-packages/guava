#ifndef INTER
#define INTER

extern int main( int argc, char *argv[])
;

#endif
