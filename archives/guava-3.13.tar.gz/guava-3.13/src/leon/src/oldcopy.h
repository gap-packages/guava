#ifndef OLDCOPY
#define OLDCOPY

extern void copyPermutation(
   const Permutation *const fromPerm,
   Permutation *const toPerm)
;

#endif
