#!/bin/sh

orblist -chbase $* 
