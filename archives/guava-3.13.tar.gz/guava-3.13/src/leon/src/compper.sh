#!/bin/sh

compgrp -perm:$1 $2 $3
