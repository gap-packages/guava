#!/bin/sh

setstab -image -partn $*
