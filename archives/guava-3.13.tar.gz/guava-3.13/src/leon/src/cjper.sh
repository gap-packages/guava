#!/bin/sh

cjrndper -perm $*
