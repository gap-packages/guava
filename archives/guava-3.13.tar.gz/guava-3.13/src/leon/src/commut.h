#ifndef COMMUT
#define COMMUT

extern int main( int argc, char *argv[])
;

#endif
