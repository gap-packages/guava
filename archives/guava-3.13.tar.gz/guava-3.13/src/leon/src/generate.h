#ifndef GENERATE
#define GENERATE

extern int main( int argc, char *argv[])
;

#endif
