#!/bin/sh

cent -group $*
