#!/bin/sh

compgrp -set:$1 $2 $3

