#!/bin/sh

commut -ncl $*
