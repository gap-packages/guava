#!/bin/sh

cent -conj $*
