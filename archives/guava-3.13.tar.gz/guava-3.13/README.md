guava
=====

GAP package guava - performs computations relative to error-correcting codes in GAP.
